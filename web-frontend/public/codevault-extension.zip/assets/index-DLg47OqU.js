const t="https://codevault-ig6c.onrender.com/gitapi",o="https://codevault-ig6c.onrender.com/api";export{t as G,o as W};
