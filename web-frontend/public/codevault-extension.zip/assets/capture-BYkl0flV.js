function o(n){var t;try{if(!((t=chrome.runtime)!=null&&t.id))return;const r={type:"capture",submission:n};chrome.runtime.sendMessage(r).then(e=>{e!=null&&e.ok?console.info("[CodeVault] synced",n.slug,e):console.warn("[CodeVault] capture not sent:",e==null?void 0:e.error)}).catch(e=>console.warn("[CodeVault] capture message failed",e))}catch{}}function l(n){return((n==null?void 0:n.textContent)??"").trim()}const c=new Set;function i(n){return c.has(n)?!1:(c.add(n),!0)}function p(n){return n.replace(/<style[^>]*>[\s\S]*?<\/style>/gi,"").replace(/<script[^>]*>[\s\S]*?<\/script>/gi,"").replace(/<head[^>]*>[\s\S]*?<\/head>/gi,"").replace(/<\/?(strong|b)>/gi,"**").replace(/<\/?(em|i)>/gi,"_").replace(/<pre[^>]*>/gi,"\n```\n").replace(/<\/pre>/gi,"\n```\n").replace(/<li[^>]*>/gi,`
- `).replace(/<\/(p|div|ul|ol|h[1-6]|section)>/gi,`

`).replace(/<br\s*\/?>/gi,`
`).replace(/<[^>]+>/g,"").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&nbsp;/g," ").replace(/&amp;/g,"&").replace(/\n{3,}/g,`

`).trim()}function g(){var r,e,a;const t=(a=(e=(r=window.monaco)==null?void 0:r.editor)==null?void 0:e.getModels)==null?void 0:a.call(e);return t&&t.length>0?t[0].getValue():null}export{p as h,i as o,g as r,o as s,l as t};
